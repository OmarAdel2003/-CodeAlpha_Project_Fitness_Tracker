import React, { useState, useEffect } from 'react';
import './App.css';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

function App() {
  const [workouts, setWorkouts] = useState([]);
  const [newWorkout, setNewWorkout] = useState({ type: '', duration: 0 });
  const [caloriesBurned, setCaloriesBurned] = useState(0);
  const [location, setLocation] = useState(null);
  const [fitnessGoal, setFitnessGoal] = useState(0);
  const [goalProgress, setGoalProgress] = useState(0);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewWorkout({ ...newWorkout, [name]: value });
  };

  const handleAddWorkout = () => {
    setWorkouts([...workouts, { ...newWorkout, location, date: new Date() }]);
    setNewWorkout({ type: '', duration: 0 });
  };

  useEffect(() => {
    const calculateCalories = () => {
      const totalCalories = workouts.reduce((acc, curr) => acc + curr.duration * 5, 0);
      setCaloriesBurned(totalCalories);
    };
    calculateCalories();
  }, [workouts]);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.error(error);
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
    }
  }, []);

  useEffect(() => {
    setGoalProgress((caloriesBurned / fitnessGoal) * 100);
  }, [caloriesBurned, fitnessGoal]);

  const handleGoalChange = (e) => {
    setFitnessGoal(e.target.value);
  };

  return (
    <div className="App">
      <h1 className="title">Fitness Tracker</h1>
      <div className="input-container">
        <input
          type="text"
          name="type"
          placeholder="Type of workout"
          value={newWorkout.type}
          onChange={handleInputChange}
        />
        <input
          type="number"
          name="duration"
          placeholder="Duration (minutes)"
          value={newWorkout.duration}
          onChange={handleInputChange}
        />
        <button onClick={handleAddWorkout}>Add Workout</button>
      </div>
      <div>
        <h2>Workouts</h2>
        <ul className="workout-list">
          {workouts.map((workout, index) => (
            <li key={index}>
              {workout.type} - {workout.duration} minutes 
              {workout.location && ` (Lat: ${workout.location.latitude}, Lng: ${workout.location.longitude})`}
            </li>
          ))}
        </ul>
      </div>
      <div className="calories-container">
        <h2>Calories Burned</h2>
        <p>{caloriesBurned} calories</p>
      </div>
      <div className="fitness-goal-container">
        <h2>Set Your Fitness Goal</h2>
        <input
          type="number"
          placeholder="Enter your fitness goal (minutes)"
          value={fitnessGoal}
          onChange={handleGoalChange}
          className={goalProgress >= 100 ? "goal-completed" : goalProgress >= 75 ? "goal-nearing" : ""}
        />
        <p>Your Fitness Goal: {fitnessGoal} minutes</p>
        {goalProgress >= 100 ? <p className="goal-message">Congratulations! You've reached your fitness goal!</p> : null}
      </div>
      <div className="progress-bar-container">
        <div className="progress-bar" style={{ width: `${goalProgress}%` }}></div>
      </div>
      <div className="progress-chart-container">
        <h2>Workout Duration Progress</h2>
        <LineChart width={600} height={300} data={workouts}>
          <XAxis dataKey="date" />
          <YAxis />
          <CartesianGrid stroke="#eee" />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="duration" stroke="#007bff" />
        </LineChart>
      </div>
    </div>
  );
}

export default App;